const got = require('got');
const cheerio = require('cheerio');
const fs = require('fs');
const { waitForDebugger } = require('inspector');
const editJsonFile = require("edit-json-file");

async function extractLinks(url)
{
  try {
    // Fetching HTML
    const response = await got(url);  
    const html = response.body;

    // Using cheerio to extract <a> tags
    const $ = cheerio.load(html);

    const linkObjects = $('a');
    // this is a mass object, not an array

    // Collect the 'href' and 'title' of each link and add them to an array
    var links = [];
    linkObjects.each((index, element) => {
      links.push({
        text: $(element).text(), // get the text
        href: $(element).attr('href'), // get the href attribute
      });
    });

    return links;
    
    // do something else here with these links, such as writing to a file or saving them to your database
  } catch (error) {
    console.log(error);
  }
};

// Try it
const URL = 'https://dirtgui.xyz/';

extractLinks(URL).then(links => {

  var loggedLinks;
  
  if (fs.existsSync('log.txt'))
    loggedLinks = fs.readFileSync('log.txt', 'utf8');
  else
  {

    fs.writeFileSync('log.txt', '');
    loggedLinks = '';
  
  }
  
  for (link of links) 
  {

    var linkInLogs = false;

    for (s of loggedLinks.split('\n')) 
    {
    
      if (s == link['href'])
      {
        linkInLogs = true;
        break;
      }
    
    }
    
    if (!linkInLogs)
      fs.writeFileSync('log.txt', link['href'] + '\n');

  }

})


// update text
fs.readFile('log.txt', 'utf8' , (err, data) => {
  if (err) {
    console.error(err)
    return
  };
})
// actually open it
fs.readFile('log.txt', 'utf8' , (err, data) => {
  if (err) {
    console.error(err)
    return
  };
  const opn = require('opn');
  opn(data)
})